export class Donor {
  name = undefined
  cnic = undefined
  status = undefined
  gender = undefined
  contact = undefined
  guardian = undefined
}
