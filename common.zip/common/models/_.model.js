export class Model {
  /** @type {string} */
  _id = undefined
}
