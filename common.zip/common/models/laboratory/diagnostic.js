export class Diagnostic {
  /** @type {string} */
  name = undefined

  /** @type {DiagnosticItem[]} */
  equipments = undefined

  /** @type {string} */
  timeRequired = undefined
}
