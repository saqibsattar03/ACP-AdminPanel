import { StockItem } from './stock-item'

/**
 * @extends StockItem
 *
 * @author Arish Khan <arishsultan104@gmail.com>
 */
export class DiagnosticItem extends StockItem {}
